<?php
session_start();
IF(!isset($_SESSION['ofor'])||(isset($_SESSION['ofor']) && $_SESSION['ofor']!==TRUE))
{
echo "Acess Denied!!!";
exit();

}
$name=$_POST['name'];
$password=$_POST["password"];
echo $name;
require('connection.php');
$qry="UPDATE owner SET password='$password' where email='$name'";
mysql_query($qry);
session_destroy();
header("location:mysql.php");
?>