﻿<!DOCTYPE html>

<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
        <title>I Feed-Love All-Serve All</title>
<!--
The Story Theme
http://www.templatemo.com/tm-480-story
-->
        <!-- load stylesheets -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,300italic,400">  <!-- Google web font "Open Sans" -->
        <link rel="stylesheet" href="css7/bootstrap.min.css">                                                <!-- Bootstrap style -->
        <link rel="stylesheet" href="css7/flexslider.css">                                                   <!-- Flexslider style -->       
        <link rel="stylesheet" href="css7/templatemo-style.css">                                             <!-- Templatemo style -->

        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    
    <body class="page">
        
            
            <!-- background images -->
            <div class="page-bg-imgs-list">
                <img src="images/bg2.jpg" id="page-1-img" class="main-img" alt="About">
                <img src="images/bg2.jpg" id="page-2-img" alt="Gallery">
                <img src="images/bg2.jpg" id="page-3-img" alt="Services">
                <img src="images/bg2.jpg" id="page-4-img" alt="Contact">                            
            </div>
            
            <div class="container-fluid">

                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-5 col-xl-5">
                        
                        <div class="header">

                            <!-- site title -->
                            <header class="box box-white">
                                <a href="index.php" class="js-site-title">
                                    <h1 class="box-text site-title-text"><b>I FEED</b></h1>    
                                </a>            
                            </header>
                            
                            <!-- site navigation -->
                            <nav class="js-nav">
                                <ul class="nav-items-container">

                                    <li data-nav-item-id="page-1" class="block-keep-ratio block-keep-ratio-1-1 block-width-half box box-white box-nav-item js-nav-item pull-xs-left">
                                        <a href="#page-1" class="block-keep-ratio-content box-nav-item-link">
                                            <span class="box-text box-text-nav-item flexbox-center">Donate</span>
                                        </a>
                                    </li>

                                    <li data-nav-item-id="page-2" class="block-keep-ratio block-keep-ratio-1-1 block-width-half box box-white box-nav-item js-nav-item pull-xs-right">
                                        <a href="#page-2" class="block-keep-ratio-content box-nav-item-link">
                                            <span class="box-text box-text-nav-item flexbox-center">Party Hall</span>
                                        </a>
                                    </li>

                                    <li data-nav-item-id="page-3" class="block-keep-ratio block-keep-ratio-1-1 block-width-half box box-white box-nav-item js-nav-item pull-xs-left">
                                        <a href="#page-3" class="block-keep-ratio-content box-nav-item-link">
                                            <span class="box-text box-text-nav-item flexbox-center">Sign-Up</span>
                                        </a>
                                    </li>

                                    <li data-nav-item-id="page-4" class="block-keep-ratio block-keep-ratio-1-1 block-width-half box box-white box-nav-item js-nav-item pull-xs-right">
                                        <a href="#page-4" class="block-keep-ratio-content box-nav-item-link">
                                            <span class="box-text box-text-nav-item flexbox-center">Sign-In</span>
                                        </a>
                                    </li>

                                </ul>
                            </nav>    
                        </div> <!-- .header -->

                    </div>

                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-7 col-xl-7">
                        <div class="content-wrapper js-content-wrapper">
                            <!-- about -->
                            <section data-page-id="page-1" class="content js-content">
                                
                                <header class="box box-black margin-b-20">
                                    <h2 class="box-text page-title-text">Save The Hungry</h2>
                                </header>
                                
                                <div class="content-text">
                                    <p>If you can’t feed a hundred people, then feed just one.</p>
                                   
									<p>
									<a href="donate.php" > <h2>Donate</h2></a> 
									</p>
                                </div>            

                            </section> <!-- #about -->

                            <!-- gallery -->
                            <section data-page-id="page-2" class="content content-gallery js-content">
                                
                                <header class="box box-black margin-b-20">
                                    <h2 class="box-text page-title-text">Look For The Best Halls</h2>
                                </header>
                                
                                <div class="content-text content-text-gallery">
                                    
                                    <!-- <p>Credits go to <a rel="nofollow" href="http://unsplash.com">Unsplash</a> for images.</p> -->

                                    <div class="flexslider-wrapper">

                                        <div id="slider" class="flexslider">
                                            <ul class="slides">
                                                <li><img src="img/slider/slide1.jpg" alt="Slide 1" /></li>
                                                <li><img src="img/slider/slide2.jpg" alt="Slide 2" /></li>
                                                <li><img src="img/slider/slide3.jpg" alt="Slide 3" /></li>
                                                <li><img src="img/slider/slide4.jpg" alt="Slide 4" /></li>
                                                <li><img src="img/slider/slide5.jpg" alt="Slide 5" /></li>
                                                
                                            </ul>
                                        </div> <!-- #slider -->
                                      
                                        <div id="carousel" class="flexslider">
                                            <ul class="slides">
                                                <li><img src="img/slider/thumb1.jpg" alt="Thumbnail 1" /></li>
                                                <li><img src="img/slider/thumb2.jpg" alt="Thumbnail 2" /></li>
                                                <li><img src="img/slider/thumb3.jpg" alt="Thumbnail 3" /></li>
                                                <li><img src="img/slider/thumb4.jpg" alt="Thumbnail 4" /></li>
                                                <li><img src="img/slider/thumb5.jpg" alt="Thumbnail 5" /></li>
													
                                            </ul>
                                        </div>  <!-- #carousel -->

                                    </div>
                                        <br>
                                <p> <a href="note.php"><h2> Look For Halls Now<h2></a></p>
								</div>            

                            </section> <!-- #gallery -->
                            
                            <!-- services -->
                            <section data-page-id="page-3" class="content js-content">
                                
                                <header class="box box-black margin-b-20">
                                    <h2 class="box-text page-title-text">Sign-up </h2>
                                </header>
                                
                                <div class="content-text">
                                    
                                    <a href="register.php"><h4>Sign up as Owner Of hall</h4></a>
                                    <p>Let your business flourish by advertising through our service. </p>
                                   <a href="nreg.php"><h4>Sign up as Organization</h4></a>
                                    <p>There people waiting to help,You just have to look.</p>
                                </div>            

                            </section> <!-- #services -->

                            <!-- contact -->
                            <section data-page-id="page-4" class="content js-content">
                                
                                <header class="box box-black margin-b-20">
                                    <h2 class="box-text page-title-text">Sign-In</h2>
                                </header>
                                
                                <div class="content-text">
                               <p class="content-text"><a href="mysql.php"><h2> Login as Owner </h2></a></p>  <p class="content-text"><a href="nin.php"><h2> Login as Organization </h2></a></p>  										
                                </div>            

                            </section> <!-- #contact -->
                        </div>
                    </div>

                </div>
                    
               

            </div>  <!-- .container-fluid -->

        <div id="preloader">
            <div id="status">&nbsp;</div>
        </div><!-- /#preloader -->      
            
        <!-- load JS files -->
        <script src="js/jquery-1.11.3.min.js"></script> <!-- jQuery -->
        <script src="js/jquery.flexslider-min.js"></script> <!-- Flex Slider -->
        <script src="js/jquery.backstretch.min.js"></script> <!-- Backstretch http://srobbin.com/jquery-plugins/backstretch/ -->
        <script src="js/templatemo-script.js"></script> <!-- Templatemo scripts -->
    
    </body>
</html>
