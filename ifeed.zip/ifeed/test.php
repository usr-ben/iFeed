<h id="s"> </h> 
<form action ="test.php" onsubmit="return validate(this);" method="POST" >
<input type="text" name="foo">
<input type="submit" value="click">
</form>

<?php 
     $str=$_POST['foo'];
		echo $str;
			
		
	
	//echo $str;
	
				//$str = stripslashes($str);
				//echo mysql_real_escape_string($str);
				

	?>
	
