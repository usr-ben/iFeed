<!-- Owner login page-->
<script type="text/javascript">
function validate(form)
{
//document.getElementById("new").innerHTML="asa";
var re=/^[a-z,A-Z,0-9,.,@,_]+$/i;
	if(!re.test(form.username.value)){
	document.getElementById("s").innerHTML="Email can contain only letters,numbers,@,.,_!!!";
	alert('Email can contain only letters,numbers,@,.,_');
	return false;
  }var re=/^[a-z,A-Z,0-9,$,_]+$/i;
	if(!re.test(form.password.value)){
	document.getElementById("s").innerHTML="Password can contain only letters,numbers,$,_!!!";
	alert('Password can contain only letters,numbers,"$","_"');
	return false;
  }
  }
  </script>
<?php

	//Start session
	session_start();	
	$_SESSION['ACCESS1']=TRUE;
	//Unset the variables stored in session
	unset($_SESSION['SESS_MEMBER_ID']);
	unset($_SESSION['SESS_FIRST_NAME']);
	unset($_SESSION['SESS_LAST_NAME']);
?>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <title>Login Form</title>
  <link rel="stylesheet" href="css5/style.css">
  <!--[if lt IE 9]><script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
</head>

<body>
  <section class="container">
    <div class="login">
      <h1>Login to Web App</h1>
      <form name="loginform" onsubmit="return validate(this);" method="post" action="login_exec.php">
	  <h1 id="s" > </h1>
<?php
			if( isset($_SESSION['ERRMSG_ARR']) && is_array($_SESSION['ERRMSG_ARR']) && count($_SESSION['ERRMSG_ARR']) >0 ) {
			echo '<ul class="err">';
			foreach($_SESSION['ERRMSG_ARR'] as $msg) {
				echo '<li>',$msg,'</li>'; 
				}
			echo '</ul>';
			unset($_SESSION['ERRMSG_ARR']);
			}
		?>       
	   <p><input type="text" name="username"  placeholder="Email"></p>
        <p><input type="password" name="password" value="" placeholder="Password"></p>
        <p class="remember_me">
          <label>
            <input type="checkbox" name="remember_me" id="remember_me">
            Remember me on this computer
          </label>
        </p>
        <p class="submit"><input type="submit" name="commit" value="Login"></p>
      </form>
    </div>

    <div class="login-help">
      <p>Forgot your password? <a href="oenter.php">Click here to reset it</a>
    </div>
  </section>
  </body>
</html>

	

