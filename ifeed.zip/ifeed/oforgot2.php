<!--owner enter answer-->
<script type="text/javascript">
function validate(form)
{
//document.getElementById("new").innerHTML="asa";
var re=/^[a-z,A-Z,0-9]+$/i;
	if(!re.test(form.answer.value)){
	document.getElementById("s").innerHTML="Answer can contain only letters,numbers!!!";
	alert('Answer can contain only letters,numbers');
	return false;
  }
  }
  </script>
<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <title>Sign Up Form</title>
  <link rel="stylesheet" href="css/style.css">
  <!--[if lt IE 9]><script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
</head>
		   <?php 
		  $name=$_POST['name'];
		  error_reporting(0);
		  require('connection.php');
$result=mysql_query("SELECT * FROM owner WHERE email='$name'");

//Check whether the query was successful or not
	
if($result)	{
	if(mysql_num_rows($result) <= 0) 
		   
		   
		   {
          header("Location: oenter.php?remarks='A'");
            }
			else{
			
		   session_start();
		  $_SESSION['reg3']=TRUE;
		}
		}
		?>


		<form class="sign-up" name="reg" action="oforgot1.php" onsubmit="return validate(this);" method="post" autocomplete="off">

		 
		
		<h1 class="sign-up-title">Enter your favourite food</h1>
	      <h1 id="s" > </h1>
		  <input name="answer" type="text" class="sign-up-input" placeholder="answer" required autofocus>
		  <input type="hidden" name="name"  value="<?php echo $name; ?>" > 
		   <input type="submit" value="Submit" class="sign-up-button">
  
</table>
</form>