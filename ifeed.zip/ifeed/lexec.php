<!-- need login validation-->
<?php

	//Start session
	session_start();
IF(!isset($_SESSION['in'])||(isset($_SESSION['in']) && $_SESSION['in']!==TRUE))
{
echo "Acess Denied!!!";
exit();
}
 
	//Include database connection details
	require_once('connection.php');
 
	//Array to store validation errors
	$errmsg_arr = array();
 
	//Validation error flag
	$errflag = false;
 
	//Function to sanitize values received from the form. Prevents SQL injection
	function clean($str) {
		$str = @trim($str);
		if(get_magic_quotes_gpc()) {
			$str = stripslashes($str);
		}
		return mysql_real_escape_string($str);
	}
 
	//Sanitize the POST values
	$username = clean($_POST['username']);
	$password = clean($_POST['password']);
 
	//Input Validations
	if($username == '') {
		$errmsg_arr[] = 'Username missing';
		$errflag = true;
	}
	if($password == '') {
		$errmsg_arr[] = 'Password missing';
		$errflag = true;
	}
 
	//If there are input validations, redirect back to the login form
	if($errflag) {
		$_SESSION['ERRMSG_ARR'] = $errmsg_arr;
		session_write_close();
		header("location: nin.php");
		exit();
	}
 
	//Create query
	$qry="SELECT * FROM need WHERE email='$username' AND password='$password'";
	$result=mysql_query($qry);

	//Check whether the query was successful or not
	if($result) {
		if(mysql_num_rows($result) > 0) {
			//Login Successful
			session_regenerate_id();
			$member = mysql_fetch_assoc($result);
			$_SESSION['SESS_MEMBER_ID'] = $member['mem_id'];
			$_SESSION['SESS_FIRST_NAME'] = $member['username'];
			$_SESSION['SESS_LAST_NAME'] = $member['password'];
			$_SESSION['ACCESS']=TRUE;
			$result1= mysql_query("SELECT area FROM need WHERE email='$username'");
			if($result1) {
		     if(mysql_num_rows($result1) > 0) {		
			$row1 = mysql_fetch_assoc($result1);
			$temp=$row1['area'];
			$_SESSION['in1']=TRUE;
			header("location: dlist.php?name=$temp");
			session_write_close();
			}
			}
			session_write_close();
			exit();
		}else {
			//Login failed
			$errmsg_arr[] = 'user name and password not found';
			$errflag = true;
			if($errflag) {
				$_SESSION['ERRMSG_ARR'] = $errmsg_arr;
				session_write_close();
				header("location: nin.php");
				exit();
			}
		}
	}else {
		die("Query failed");
	}
?>