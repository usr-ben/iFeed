<script type="text/javascript">
function validate(form)
{
//document.getElementById("new").innerHTML="asa";
var re=/^[a-z,A-Z]+$/i;
	if(!re.test(form.name.value)){
	document.getElementById("s").innerHTML="Name can contain only letters!!!";
	alert('Name can contain only letters');
	return false;
  }
  var re=/^[0-9,+]+$/i;
	if(!re.test(form.contact.value)){
	document.getElementById("s").innerHTML="Contact can contain only numbers and +";
	alert('Contact can contain only numbers and +');
	
	return false;
  }var re=/^[a-z,A-Z,0-9,@,_,.]+$/i;
	if(!re.test(form.mail.value)){
	document.getElementById("s").innerHTML="Email can contain only letters numbers and _,.,@";
	alert('Email can contain only letters numbers and _,.,@');
	return false;
  }var re=/^[a-z,A-Z,0-9,$,_]+$/i;
	if(!re.test(form.pass.value)){
	document.getElementById("s").innerHTML="Password can contain only letters numbers and _,$";
	alert('Password can contain only letters numbers and _,$');
	return false;
 
  }var re=/^[a-z,A-Z,0-9]+$/i;
	if(!re.test(form.area.value)){
	document.getElementById("s").innerHTML="Area can contain only letters numbers";
	alert('Area can contain only letters numbers');
	return false;
  }var re=/^[a-z,A-Z,0-9,#,-,,]+$/i;
	if(!re.test(form.address.value)){
	document.getElementById("s").innerHTML="Address can contain only letters numbers and #,-,,";
	alert('Address can contain only letters numbers and #,-,,');
	return false;
	 }var re=/^[a-z,A-Z,0-9]+$/i;
	if(!re.test(form.no.value)){
	document.getElementById("s").innerHTML="No of children can contain only numbers";
	alert('No of children can contain only numbers');
	return false;
  }var re=/^[a-z,A-Z,0-9]+$/i;
	if(!re.test(form.answer.value)){
	document.getElementById("s").innerHTML="Answer can contain only letters numbers";
	alert('Answer can contain only letters numbers');
	return false;

}
}
</script>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <title>Sign Up Form</title>
  <link rel="stylesheet" href="css/style.css">
  <!--[if lt IE 9]><script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
</head>
<body>

<form class="sign-up" name="reg" action="exec.php" onsubmit="return validate(this);" method="post" autocomplete="off" >

		  <?php 
		  error_reporting(0);
		  session_start();
		  $_SESSION['nreg1']=TRUE;
		$remarks=$_GET['remarks'];
		if ($remarks==null and $remarks=="")
		{
		echo '';
		}
		if ($remarks=='success')
		{
		echo 'Registration Success';
		}
		if ($remarks=="'a'")
		{
		echo "Email already exists!!!!!";
		}
		?>	
		<h1 class="sign-up-title">Organization Registration</h1>
		 <h1 id="s" > </h1>
	      <input name="name" type="text" class="sign-up-input" placeholder="your name?" required autofocus>
    <input name="contact" type="text" class="sign-up-input" placeholder="contact number" required autofocus>
<input name="mail" type="text" class="sign-up-input" placeholder="mail" required autofocus>
	 <input name="pass" type="password" class="sign-up-input" placeholder="pass" required autofocus>	
	<input name="area" type="text" class="sign-up-input" placeholder="your area" required autofocus>
	  <input name="address" type="text" class="sign-up-input" placeholder="house no and cross no " required autofocus>
	  <input name="no" type="text" class="sign-up-input" placeholder="No of people " required autofocus>
	  <input name="answer" type="text" class="sign-up-input" placeholder="Favourite food? " required autofocus>
	   <input type="submit" value="SignUP!" class="sign-up-button">
  
</table>

</form>
</body>
