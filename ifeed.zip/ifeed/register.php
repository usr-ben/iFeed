<!-- owner registration-->
<script type="text/javascript">
function validateForm(form)
{
var re=/^[a-z,A-Z]+$/i;
	if(!re.test(form.name.value)){
	document.getElementById("s").innerHTML="Name can contain only letters!!!";
	alert('Name can contain only letters');
	return false;
  }
  var re=/^[0-9,+]+$/i;
	if(!re.test(form.contact.value)){
	document.getElementById("s").innerHTML="Contact can contain only numbers and +!!!";
	alert('Contact can contain only numbers and +');
	return false;
  }var re=/^[a-z,A-Z,0-9,@,_,.]+$/i;
	if(!re.test(form.mail.value)){
	document.getElementById("s").innerHTML="Email can contain only letters numbers and _,.,@!!!";
	alert('Email can contain only letters numbers and _,.,@');
	return false;
  }var re=/^[a-z,A-Z,0-9,$,_]+$/i;
	if(!re.test(form.pass.value)){
	document.getElementById("s").innerHTML="Password can contain only letters numbers and _,$!!!";
	alert('Password can contain only letters numbers and _,$');
	return false;
  }var re=/^[a-z,A-Z,0-9]+$/i;
	if(!re.test(form.hallname.value)){
     document.getElementById("s").innerHTML="Hallname can contain only letters numbers!!!";
	alert('Hallname can contain only letters numbers');
	return false;
  }var re=/^[a-z,A-Z,0-9,#,-,,]+$/i;
	if(!re.test(form.descr.value)){
	document.getElementById("s").innerHTML="Description can contain only letters numbers and #,-,,!!!";
	alert('Description can contain only letters numbers and #,-,,');
	return false;
  }var re=/^[a-z,A-Z,0-9]+$/i;
	if(!re.test(form.area.value)){
	document.getElementById("s").innerHTML="Area can contain only letters numbers!!!";
	alert('Area can contain only letters numbers');
	return false;
  }var re=/^[a-z,A-Z,0-9,#,-,,]+$/i;
	if(!re.test(form.address.value)){
	document.getElementById("s").innerHTML="Address can contain only letters numbers!!!";
	alert('Address can contain only letters numbers and #,-,,');
	return false;
  }var re=/^[a-z,A-Z,0-9]+$/i;
	if(!re.test(form.answer.value)){
	document.getElementById("s").innerHTML="Answer can contain only letters numbers!!!";
	alert('Answer can contain only letters numbers');
	return false;
  }3
var a=document.forms["reg"]["name"].value;
var b=document.forms["reg"]["contact"].value;
var c=document.forms["reg"]["email"].value;
var d=document.forms["reg"]["password"].value;
var e=document.forms["reg"]["hallname"].value;
var f=document.forms["reg"]["descr"].value;	
var g=document.forms["reg"]["area"].value;
var h=document.forms["reg"]["address"].value;
if ((a==null || a=="") && (b==null || b=="") && (c==null || c=="") && (d==null || d=="") && (e==null || e=="") && (f==null || f==""))
  {
  alert("All Field must be filled out");
  return false;
  }
if (a==null || a=="")
  {
  alert("First name must be filled out");
  return false;
  }
if (b==null || b=="")
  {
  alert("Last name must be filled out");
  return false;
  }
if (c==null || c=="")
  {
  alert("Gender name must be filled out");
  return false;
  }
if (d==null || d=="")
  {
  alert("address must be filled out");
  return false;
  }
if (e==null || e=="")
  {
  alert("contact must be filled out");
  return false;
  }
if (f==null || f=="")
  {
  alert("picture must be filled out");
  return false;
  }
if (g==null || g=="")
  {
  alert("username must be filled out");
  return false;
  }
if (h==null || h=="")
  {
  alert("password must be filled out");
  return false;
  }
 
}
  </script>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <title>Sign Up Form</title>
  <link rel="stylesheet" href="css/style.css">
  <!--[if lt IE 9]><script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
</head>

<form class="sign-up" name="reg" action="code_exec.php" onsubmit="return validateForm(this);" method="post" autocomplete="off">

		  <?php
		  session_start();
		  $_SESSION['reg2']=TRUE;
error_reporting(0);		  
		$remarks=$_GET['remarks'];
		if ($remarks==null and $remarks=="")
		{
		echo '';
		}
		if ($remarks=='success')
		{
		echo 'Registration Success';
		}
		if ($remarks=="'a'")
		{
		echo "Email already exists!!!!!";
		}
		?>	
		<h1 class="sign-up-title">Signup in seconds</h1>
		    <h1 id="s" > </h1>
		  <input name="name" type="text" class="sign-up-input" placeholder="your name?" required autofocus>
    <input name="contact" type="text" class="sign-up-input" placeholder="contact number" required autofocus>
	<input name="mail" type="text" class="sign-up-input" placeholder="mail" required autofocus>
	 <input name="pass" type="password" class="sign-up-input" placeholder="pass" required autofocus>
	 <input name="hallname" type="text" class="sign-up-input" placeholder="HALL NAME" required autofocus>
	 <input name="descr" type="text" class="sign-up-input" placeholder="Description about hall" required autofocus>
	 <input name="area" type="text" class="sign-up-input" placeholder="your area" required autofocus>
	  <input name="address" type="text" class="sign-up-input" placeholder="house no and cross no " required autofocus>
	   <input name="answer" type="text" class="sign-up-input" placeholder="Favourite food? " required autofocus>
	   <input type="submit" value="SignUP!" class="sign-up-button">
  
</table>
</form>

